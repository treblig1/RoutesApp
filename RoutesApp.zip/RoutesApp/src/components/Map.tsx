import React, {useEffect, useRef, useState} from 'react'
import MapView, { MapMarker, Polyline } from 'react-native-maps';
import { useLocation } from '../hooks/useLocation';
import { LoadingScreen } from '../pages/LoadingScreen';
import { Fab } from './Fab';

interface Props {
  markers?: MapMarker[];
}

export const Map = ({ markers }: Props) => {

  const [ showPolyLines, setShowPolyLines ] = useState(true)
  
  const { 
    hasLocation, 
    initialPosition, 
    getCurrentLocation, 
    followUserLocation, 
    userLocation,
    stopFollowLocation,
    routeLines } = useLocation();

  const mapViewRef = useRef<MapView>();
  const following = useRef<boolean>(true);


  useEffect(() => {
    followUserLocation();
  
    return () => {
      stopFollowLocation();
    }
  }, [])

  useEffect(() => {

      if ( !following.current ) return;

      const { latitude, longitude } = userLocation;
      mapViewRef.current?.animateCamera({
        center: { latitude, longitude }
    })
    
  }, [ userLocation ])
  
  

  const centerPosition = async() => {

    const { longitude, latitude } = await getCurrentLocation();

    following.current = true;

    mapViewRef.current?.animateCamera({
      center: { latitude, longitude }
    })
  }

  
  if ( !hasLocation ) {
      <LoadingScreen />

  }

  return (
    <>
        <MapView
            ref={ (el) => mapViewRef.current = el!}
            showsUserLocation
            style={{flex: 1}}
            initialRegion={{
            latitude: initialPosition.latitude,
            longitude: initialPosition.longitude,
            latitudeDelta: 0.015,
            longitudeDelta: 0.0121,
            }}
            onTouchStart={ () => following.current = false }
        >
            {
              showPolyLines && (
                <Polyline 
                  coordinates={ routeLines }
                  strokeColor='black'
                  strokeWidth={ 3 }
                  
                />
              )
            }

        </MapView>
          
        <Fab 
          iconName='compass-outline'
          onPress={ centerPosition }
          style={{
            position: 'absolute',
            bottom: 20,
            right: 20
          }}
        />

        <Fab 
          iconName='brush-outline'
          onPress={ () => setShowPolyLines( !showPolyLines ) }
          style={{
            position: 'absolute',
            bottom: 80,
            right: 20
          }}
        />

    </>
  )
}
