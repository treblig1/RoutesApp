import React, { useContext } from 'react'
import { Button, Platform, StyleSheet, Text, View } from 'react-native';
import { check, request, PERMISSIONS, PermissionStatus } from 'react-native-permissions';
import { BlackButton } from '../components/BlackButton';
import { PermissionsContext } from '../context/PermissionsContext';

export const PermissionsScreen = () => {

  const { permissions, askLocationPermission } = useContext(PermissionsContext);

  return (
    <View style={styles.container}>
        <Text style={styles.textColor}>Es Necesario el uso de GPS para esta aplicación</Text>

        <BlackButton 
          onPress={askLocationPermission}
          title= 'Permiso'
        />

        <Text style={{marginTop: 20}}> {JSON.stringify(permissions, null, 5)} </Text>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  textColor: {
    color: 'black',
    fontSize: 16,
    alignItems: 'center',
    marginBottom: 20
    

  }
})